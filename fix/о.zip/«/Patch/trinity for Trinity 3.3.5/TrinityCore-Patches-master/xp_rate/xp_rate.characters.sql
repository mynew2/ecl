ALTER TABLE  `characters` ADD  `xp_rate` FLOAT NOT NULL DEFAULT  '1' AFTER  `grantableLevels`;
