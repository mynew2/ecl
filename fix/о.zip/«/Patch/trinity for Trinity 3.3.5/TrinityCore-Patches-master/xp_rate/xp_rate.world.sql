INSERT INTO `command` (`name`, `security`, `help`) VALUES ('xprate', '0', 'Syntax: .xprate x.y

Modifies the rate at which you gain experience. To disable experience gain, set to 0. Range: 0 - 5');
