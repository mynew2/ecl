UPDATE `creature_template` SET `Mana_mod` = '0.2' WHERE `entry` = 36855;
UPDATE `creature_template` SET `Mana_mod` = '0.2' WHERE `entry` = 38106;
UPDATE `creature_template` SET `Mana_mod` = '0.2' WHERE `entry` = 38296;
UPDATE `creature_template` SET `Mana_mod` = '0.2' WHERE `entry` = 38297;