Gambling patch from spgm repo ported to OregonCore.  Adds two commands - gamble
and roulette.  

Goofy little patch - I doubt that I would use it, but it was an easy port.

-- Celtus
