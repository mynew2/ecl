This is a patch from the SD2 project, which I have modified slightly.  The
mod is basically to pull the item/creature link from the database instead of
hardcoding it.  

The script lets you use an item to summon a creature.

-- Celtus
