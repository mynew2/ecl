From ImpConfig - Award gold to winner of duel.
