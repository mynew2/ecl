This code was found on a MaNGOS forum sometime in late 2008 or early 2009.
The post was written by Lunera.  I assume that Lunera is the original author.

-- Celtus

