This patch uses the code found in the TrinityCore codebase.  The only minor
changes were for file locations, and to modify the database table for future
integration with the IRC announcement table structure - as well as providing
a flag to allow rows to be skipped by the engine, but remain available for
later use.

-- Celtus

