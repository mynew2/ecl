This is an interesting patch.  It allows a GM to monitor all the chat from a 
player (or players). 

I can't find anything which indicates the original author.  It seems to have
been written for MaNGOS quite a long time ago.

-- Celtus
