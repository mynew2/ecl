This is a script that lets an NPC exchange a token (configurable) for gold,
arena points, honor points, levels, or max skills.

This is my code, but I was inspired by some of the posting on the TC2 forums.

Since it is my code, I hereby authorize anyone to use it however you please.
It would be nice if you kept my name on it, though (and much more honest, I
think).

Enjoy, 

-- Celtus

