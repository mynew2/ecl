This is a custom item script that teleports a player.  I don't know where it
came from, and I might possibly have written most of it.  It's a quick and
dirty script, but it gets the job done.

-- Celtus

