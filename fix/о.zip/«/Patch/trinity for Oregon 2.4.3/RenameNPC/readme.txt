I don't have any idea where this code came from.  The basic code was given to
me by a forum member. 

This NPC will set the rename flag for a character.  Options are in the 
oregoncore.conf file.

-- Celtus

