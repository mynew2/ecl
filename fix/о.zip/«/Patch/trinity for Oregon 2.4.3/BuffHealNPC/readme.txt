Originally created by Klark20, this is 2 NPCs - one that gives big-time buffs
and gold, and another that gives a couple of buffs and will heal.

I believe I found these on a forum long ago, and they may have been passed
along by the SD2 group for awhile.

I don't actually use these, but had them spawned for a raid event once.

-- Celtus

