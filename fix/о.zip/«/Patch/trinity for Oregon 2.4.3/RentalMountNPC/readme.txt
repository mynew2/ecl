This script allows an NPC to sell temporary mounts to players.  At the moment, 
there are no level restrictions, but I may add them later.

Requires new entries to oregoncore.conf - see oregoncore.conf.dist.

Original source unknown.  This was given to me by a forum member.

-- Celtus
