This is all of the individual patches combined.

NOTE!  This is built against r1055 using the new script system - it will not
apply cleanly to any rev before r760.
