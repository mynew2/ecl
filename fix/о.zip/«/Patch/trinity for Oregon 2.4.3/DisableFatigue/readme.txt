This patch adds a configuration option to disable fatigue above a specified
GM level.  Works in much the same way that DisableWaterBreath works.

-- Celtus
