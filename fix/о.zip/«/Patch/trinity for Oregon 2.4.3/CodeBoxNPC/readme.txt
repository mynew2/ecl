I don't have any idea where this code came from.  Some of it was from a forum,
I'm sure, but I've modified it considerably since then.

This NPC will ask for a code, and give a reward.  My main reason for it was to
make the two mobs in IF give up the Murloc Suit and pets.  

This is just kind of a fun thing to have around, in my opinion.

-- Celtus

