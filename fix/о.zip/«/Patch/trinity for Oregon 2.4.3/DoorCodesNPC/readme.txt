I love this patch!  This is based on an idea posted on the TC2 forum by Pixeel.

The patch provides code-locked doors.  The NPC that unlocks then must be
within 10 feet (in-game) of the door gameobject.

-- Celtus
