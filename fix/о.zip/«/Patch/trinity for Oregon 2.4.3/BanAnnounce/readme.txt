This patch will broadcast Ban/Mute/Kick to the world.  The message will have
the name of the player, and the gmlevel of the person who banned, muted, or
kicked them.  The strings for each gmlevel are:

1: GameMaster
2: Moderator
3: Administrator
4: System

To enable announcements, set ShowKickInWorld = 1 in oregoncore.conf.

Original source unknown.

-- Celtus

