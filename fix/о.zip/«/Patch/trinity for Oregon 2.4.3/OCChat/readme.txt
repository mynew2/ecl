This is a port of TriniChat2, as currently maintained by spgm, et al.

** Work in progress as of 9.11.2010 **

TODO:

* Merge/blend/mangle autobroadcast to use the newer/better code from TC2. DONE!
* Rewrite queries to characters to reference new schema - quicker, I bet.
* Remove unfinished or broken pieces that just don't need to be there.
* Probably much more I haven't even thought of, yet.

2010-09-12: Merged broadcast in All patch - coming soon to stand-alone OCChat.

UPDATE: Merge is now in stand-alone.  If you load this, you should not load
        the stand-alone AutoBroadcast - It's already in here.

-- Celtus

