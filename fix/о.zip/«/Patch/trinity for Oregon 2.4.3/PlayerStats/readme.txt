This patch is based on the playerstats code in TrinityCore.  The purpose is
to create a table of easily readable player information that can be used by
a website, or reporting tool.

The data is only written to the table on character logoff.

-- Celtus
