Based on a concept by Pwntzyou.  This little command lets you teleport up,
down, forward, or back by a number of coordinate units.  Kind of neat.

-- Celtus
