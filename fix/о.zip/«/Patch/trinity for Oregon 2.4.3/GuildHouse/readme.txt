This is the GuildHouse script from spgm with minor modifications.  Needs more
houses in the file, but it works well.

-- Celtus

