This patch beefs up the PvP system a bit for low-pop servers, and sets more
attainable limits for the Titles.

This patch has been around for awhile, so here are the credits, as I found
them:

Originally posted by: freeganja and Written by: Albrecht de Endrau from MaNGOS
forum.

Ported to TC by Atreus on TC forum.

Ported to OC by Niyo and rescr1pt on OC forum.

-- Celtus

