This is a general-purpose guard that can be set up in the database.  It will
remove players who are not sepcified when they get within range.  The range
and teleport destination are set in the table for each guard creature_id.

This is kind of quick and dirty.  I plan to have the data load at script
startup at some point.

-- Celtus
